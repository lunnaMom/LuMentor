# LuMentor

Обучающее Java-приложение с XP, тестами и встроенным логгером (LumiGhost).